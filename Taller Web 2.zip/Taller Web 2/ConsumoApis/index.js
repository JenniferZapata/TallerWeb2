async function fetchFotos() {
    let response = await fetch('https://jsonplaceholder.typicode.com/photos');
    let datos = await response.json();
    return datos.slice(0, 10); 
}

async function mostrarFotos() {
    let fotos = await fetchFotos();
    let galeria = document.getElementById('galeria');
    fotos.forEach(foto => {
        let fotoElemento = document.createElement('div');
        fotoElemento.innerHTML = `
            <h3>${foto.title}</h3>
            <img class="foto" src="${foto.thumbnailUrl}" alt="${foto.title}">
        `;
        galeria.appendChild(fotoElemento);
    });
}
mostrarFotos();